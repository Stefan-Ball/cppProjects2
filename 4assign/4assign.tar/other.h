#ifndef OTHER_H
#define OTHER_H
int find_grid_size(int, char **);
void ask_question(int &, int, int, string);

#endif
